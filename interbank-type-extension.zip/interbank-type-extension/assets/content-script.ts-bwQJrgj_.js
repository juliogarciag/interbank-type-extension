import{t as s}from"./content-script-C8DYVNGZ.js";export{s as typePassword};
