import{t as s}from"./content-script-MkEmm-5F.js";export{s as typePassword};
